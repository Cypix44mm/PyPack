import tkinter as tk
from tkinter import filedialog, messagebox
import json
import struct
import os
from typing import List, Dict, Tuple

# -----------------------
# Oran - Packaged Audio Manipulation Program
# -----------------------
# Custom binary .fresh format:
# [MAGIC 'ORANFRESH' (9 bytes)] [VERSION (1 byte)] [MANIFEST_LEN (8 bytes, Q)]
# [MANIFEST JSON (utf-8, MANIFEST_LEN bytes)]
# [FILE_1_BYTES][FILE_2_BYTES]...[FILE_N_BYTES]
#
# Manifest example:
# { "files": [ {"name": "song1.mp3", "size": 12345}, {"name": "song2.mp3", "size": 45678} ] }
#
MAGIC = b"ORANFRESH"
VERSION = b"\x01"
MANIFEST_LEN_FORMAT = "<Q"   # unsigned long long, little endian

# Colors (Oran theme)
DARK_ORANGE = "#ff6600"   # rim + accent
LIGHT_ORANGE = "#ffb84d"  # items
BG_ORANGE = "#fff3e6"
WHITE = "#ffffff"

# -----------------------
# Helper functions
# -----------------------
def build_manifest(file_infos: List[Dict]) -> bytes:
    """Return manifest JSON bytes from file info list."""
    manifest = {"files": file_infos}
    j = json.dumps(manifest, ensure_ascii=False).encode("utf-8")
    return j

def parse_manifest(b: bytes) -> Dict:
    return json.loads(b.decode("utf-8"))

def safe_basename(path: str) -> str:
    return os.path.basename(path)

def human_size(n: int) -> str:
    for unit in ("B","KB","MB","GB"):
        if n < 1024.0:
            return f"{n:3.1f}{unit}"
        n /= 1024.0
    return f"{n:.1f}TB"

# -----------------------
# Core package functions
# -----------------------
def create_fresh_package(target_path: str, input_files: List[str]) -> None:
    """
    Create a .fresh package at target_path containing files in input_files (list of paths).
    Writes manifest then concatenates each file binary.
    """
    file_infos = []
    for p in input_files:
        size = os.path.getsize(p)
        file_infos.append({"name": safe_basename(p), "size": size})

    manifest_bytes = build_manifest(file_infos)
    manifest_len = len(manifest_bytes)

    # Write package
    with open(target_path, "wb") as out:
        out.write(MAGIC)
        out.write(VERSION)
        out.write(struct.pack(MANIFEST_LEN_FORMAT, manifest_len))
        out.write(manifest_bytes)

        # append each file's raw bytes
        for p in input_files:
            with open(p, "rb") as f:
                # stream copy
                while True:
                    chunk = f.read(1024*64)
                    if not chunk:
                        break
                    out.write(chunk)

def read_fresh_package(path: str) -> Tuple[List[Dict], int]:
    """
    Read a .fresh package and return (file_list, data_start_offset).
    file_list is the manifest['files'] list (each has 'name' and 'size').
    data_start_offset is the file position where binary data begins (so you can seek).
    """
    with open(path, "rb") as f:
        magic = f.read(len(MAGIC))
        if magic != MAGIC:
            raise ValueError("Not a valid .fresh file (magic mismatch)")
        version = f.read(1)
        if version != VERSION:
            # still accept, but warn — for now require exact version
            raise ValueError("Unsupported .fresh version")

        manifest_len_bytes = f.read(struct.calcsize(MANIFEST_LEN_FORMAT))
        if len(manifest_len_bytes) != struct.calcsize(MANIFEST_LEN_FORMAT):
            raise ValueError("Corrupt .fresh file (manifest length missing)")
        (manifest_len,) = struct.unpack(MANIFEST_LEN_FORMAT, manifest_len_bytes)

        manifest_bytes = f.read(manifest_len)
        if len(manifest_bytes) != manifest_len:
            raise ValueError("Corrupt .fresh file (manifest truncated)")

        manifest = parse_manifest(manifest_bytes)
        files = manifest.get("files", [])
        data_start = f.tell()
        return files, data_start

def extract_from_fresh(fresh_path: str, out_dir: str, indices: List[int]=None) -> List[str]:
    """
    Extract selected indices (list of integer indices) from fresh_path into out_dir.
    If indices is None -> extract all.
    Returns list of output file paths written.
    """
    files, data_start = read_fresh_package(fresh_path)
    # compute offsets
    offsets = []
    offset = data_start
    for entry in files:
        offsets.append(offset)
        offset += int(entry["size"])

    # select indices
    if indices is None:
        indices = list(range(len(files)))

    written = []
    with open(fresh_path, "rb") as f:
        for i in indices:
            if i < 0 or i >= len(files):
                continue
            entry = files[i]
            name = entry["name"]
            size = int(entry["size"])
            start = offsets[i]
            f.seek(start)
            out_path = os.path.join(out_dir, name)
            # avoid overwriting by adding suffix if needed
            base, ext = os.path.splitext(out_path)
            suffix = 1
            while os.path.exists(out_path):
                out_path = f"{base} ({suffix}){ext}"
                suffix += 1
            with open(out_path, "wb") as out:
                remaining = size
                while remaining:
                    chunk_size = 65536 if remaining >= 65536 else remaining
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    out.write(chunk)
                    remaining -= len(chunk)
            written.append(out_path)
    return written

# -----------------------
# GUI code (Tkinter)
# -----------------------
class OranApp:
    def __init__(self, master: tk.Tk):
        self.master = master
        master.title("Oran - Packaged Audio Manipulation Program")
        master.geometry("920x600")
        master.configure(bg=DARK_ORANGE)

        # Data model: list of dicts { 'src_path': optional original path, 'name': filename, 'size': int }
        # When loaded from .fresh, src_path is None (we only have package data).
        self.items: List[Dict] = []

        # Build UI
        self._build_ui()

    def _build_ui(self):
        # Outer frame to create thick rim
        outer = tk.Frame(self.master, bg=DARK_ORANGE, bd=12)
        outer.pack(expand=True, fill="both")

        header_frame = tk.Frame(outer, bg=BG_ORANGE)
        header_frame.pack(fill="x", padx=6, pady=(6,4))

        header_label = tk.Label(
            header_frame,
            text="Welcome to Oran - Packaged Audio Manipulation Program",
            bg=BG_ORANGE,
            fg=DARK_ORANGE,
            font=("Segoe UI", 12, "bold"),
            anchor="w",
            padx=8,
            pady=6
        )
        header_label.pack(fill="x")

        # Main region: left = listbox, right = preview/details + buttons
        main_frame = tk.Frame(outer, bg=WHITE)
        main_frame.pack(expand=True, fill="both", padx=6, pady=6)

        # Left: list of files
        left_frame = tk.Frame(main_frame, bg=WHITE)
        left_frame.pack(side="left", fill="both", expand=True, padx=(8,4), pady=8)

        lbl = tk.Label(left_frame, text="Files in package / staging area", bg=WHITE, fg="black", anchor="w", font=("Segoe UI", 10, "bold"))
        lbl.pack(fill="x")

        # Listbox with scrollbar
        self.listbox = tk.Listbox(left_frame, selectmode=tk.EXTENDED, activestyle='none',
                                  font=("Courier New", 11), bg="white", fg="black",
                                  selectbackground=DARK_ORANGE, selectforeground="white",
                                  highlightthickness=1, relief="solid")
        self.listbox.pack(side="left", fill="both", expand=True, pady=6)

        sb = tk.Scrollbar(left_frame, orient="vertical", command=self.listbox.yview)
        sb.pack(side="right", fill="y")
        self.listbox.config(yscrollcommand=sb.set)

        # Right: controls
        right_frame = tk.Frame(main_frame, width=320, bg=WHITE)
        right_frame.pack(side="right", fill="y", padx=(6,10), pady=8)

        # Info area
        info_lbl = tk.Label(right_frame, text="Selected file info", bg=WHITE, fg="black", anchor="w", font=("Segoe UI", 10, "bold"))
        info_lbl.pack(fill="x")

        self.info_text = tk.Text(right_frame, height=8, bg=WHITE, fg="black", font=("Segoe UI", 10), state="disabled", wrap="word", relief="solid")
        self.info_text.pack(fill="x", pady=(4,10))

        # Buttons
        btn_frame = tk.Frame(right_frame, bg=WHITE)
        btn_frame.pack(fill="x", pady=(8,0))

        add_btn = tk.Button(btn_frame, text="➕ Add Audio", command=self.on_add, bg=DARK_ORANGE, fg="white", activebackground=LIGHT_ORANGE, padx=8, pady=6)
        add_btn.pack(fill="x", pady=4)

        remove_btn = tk.Button(btn_frame, text="❌ Remove Selected", command=self.on_remove, bg="#e85a00", fg="white", activebackground=LIGHT_ORANGE, padx=8, pady=6)
        remove_btn.pack(fill="x", pady=4)

        save_btn = tk.Button(btn_frame, text="💾 Save as .fresh", command=self.on_save, bg=DARK_ORANGE, fg="white", activebackground=LIGHT_ORANGE, padx=8, pady=6)
        save_btn.pack(fill="x", pady=4)

        open_btn = tk.Button(btn_frame, text="📂 Open .fresh", command=self.on_open, bg=DARK_ORANGE, fg="white", activebackground=LIGHT_ORANGE, padx=8, pady=6)
        open_btn.pack(fill="x", pady=4)

        extract_btn = tk.Button(btn_frame, text="📤 Extract Selected", command=self.on_extract_selected, bg="#ff8f33", fg="white", activebackground=LIGHT_ORANGE, padx=8, pady=6)
        extract_btn.pack(fill="x", pady=4)

        extract_all_btn = tk.Button(btn_frame, text="📤 Extract All", command=self.on_extract_all, bg="#ffac66", fg="black", activebackground=LIGHT_ORANGE, padx=8, pady=6)
        extract_all_btn.pack(fill="x", pady=4)

        clear_btn = tk.Button(btn_frame, text="🧹 Clear List", command=self.on_clear, bg="#d9534f", fg="white", padx=8, pady=6)
        clear_btn.pack(fill="x", pady=6)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status = tk.Label(outer, textvariable=self.status_var, anchor="w", bg=DARK_ORANGE, fg="white", padx=8)
        status.pack(fill="x")

        # Bind selection event
        self.listbox.bind("<<ListboxSelect>>", lambda e: self.update_info())

    # -------------------------
    # UI actions
    # -------------------------
    def on_add(self):
        files = filedialog.askopenfilenames(title="Select MP3 files", filetypes=[("MP3 files","*.mp3"), ("All files","*.*")])
        if not files:
            return
        added = 0
        for p in files:
            try:
                size = os.path.getsize(p)
                name = safe_basename(p)
                # Prevent duplicate names in list; if duplicate, make unique with suffix
                existing_names = [it["name"] for it in self.items]
                if name in existing_names:
                    base, ext = os.path.splitext(name)
                    suffix = 1
                    new_name = f"{base} ({suffix}){ext}"
                    while new_name in existing_names:
                        suffix += 1
                        new_name = f"{base} ({suffix}){ext}"
                    name = new_name
                self.items.append({"src_path": p, "name": name, "size": size})
                self.listbox.insert(tk.END, f"{name}   ({human_size(size)})")
                added += 1
            except Exception as e:
                messagebox.showwarning("Warning", f"Could not add file {p}:\n{e}")
        self.status_var.set(f"Added {added} file(s).")

    def on_remove(self):
        sel = list(self.listbox.curselection())
        if not sel:
            messagebox.showinfo("Remove", "No files selected.")
            return
        # remove highest indices first
        for i in reversed(sel):
            del self.items[i]
            self.listbox.delete(i)
        self.status_var.set(f"Removed {len(sel)} file(s).")
        self.update_info()

    def on_clear(self):
        if not self.items:
            return
        if not messagebox.askyesno("Clear", "Clear all files from staging area?"):
            return
        self.items.clear()
        self.listbox.delete(0, tk.END)
        self.status_var.set("Cleared list.")
        self.update_info()

    def on_save(self):
        if not self.items:
            messagebox.showinfo("Save", "No files to save.")
            return
        target = filedialog.asksaveasfilename(title="Save package as", defaultextension=".fresh", filetypes=[("Oran package","*.fresh"), ("All files","*.*")])
        if not target:
            return
        try:
            # For create, if some entries came from existing package (no src_path),
            # we can't write them unless we kept their data; currently,
            # we only allow adding actual mp3s from disk. If user opened a .fresh and didn't
            # add new files, we stored no src_path; to support re-saving open packages
            # we need to grab the data from the source package. To keep things simple
            # we will support re-saving only when either items have src_path or the
            # package we opened is available (handled by on_open which stores package path and
            # a temporary mapping). For simplicity here we only write items that have src_path.
            #
            # To enable re-saving packages that originated from a .fresh open, we store
            # the package_path & offsets on self when opening and use them to read data.
            input_sources = []
            # if an item has 'src_path' use it; otherwise if item has 'pkg_src' use that and offset
            for it in self.items:
                if it.get("src_path"):
                    input_sources.append(("file", it["src_path"], it["name"], it["size"]))
                elif it.get("pkg_src"):
                    input_sources.append(("pkg", (it["pkg_src"], it["pkg_offset"], it["size"]), it["name"], it["size"]))
                else:
                    raise RuntimeError("Item missing source (cannot save)")

            # We'll build manifest using filenames and sizes. While writing we stream either from disk file or from original package.
            file_infos = []
            for kind, src, name, size in input_sources:
                file_infos.append({"name": name, "size": int(size)})

            manifest_bytes = build_manifest(file_infos)
            manifest_len = len(manifest_bytes)

            with open(target, "wb") as out:
                out.write(MAGIC)
                out.write(VERSION)
                out.write(struct.pack(MANIFEST_LEN_FORMAT, manifest_len))
                out.write(manifest_bytes)
                # now stream each file's bytes
                for kind, src, name, size in input_sources:
                    if kind == "file":
                        path = src  # path string
                        with open(path, "rb") as f:
                            while True:
                                chunk = f.read(1024*64)
                                if not chunk:
                                    break
                                out.write(chunk)
                    else:
                        # kind == "pkg", src is tuple (pkg_path, offset, size)
                        pkg_path, offset, total_size = src
                        with open(pkg_path, "rb") as pf:
                            pf.seek(offset)
                            remaining = total_size
                            while remaining:
                                read_size = 65536 if remaining >= 65536 else remaining
                                chunk = pf.read(read_size)
                                if not chunk:
                                    break
                                out.write(chunk)
                                remaining -= len(chunk)
            self.status_var.set(f"Saved package: {target}")
            messagebox.showinfo("Saved", f"Package saved to:\n{target}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save package:\n{e}")

    def on_open(self):
        path = filedialog.askopenfilename(title="Open .fresh package", filetypes=[("Oran package","*.fresh"), ("All files","*.*")])
        if not path:
            return
        try:
            files, data_start = read_fresh_package(path)
            # build internal items structure with pkg_src details
            self.items.clear()
            self.listbox.delete(0, tk.END)
            offset = data_start
            for entry in files:
                name = entry["name"]
                size = int(entry["size"])
                self.items.append({"src_path": None, "pkg_src": path, "pkg_offset": offset, "name": name, "size": size})
                self.listbox.insert(tk.END, f"{name}   ({human_size(size)})")
                offset += size
            self.status_var.set(f"Opened package: {path} ({len(files)} items)")
            self.update_info()
        except Exception as e:
            messagebox.showerror("Error", f"Could not open package:\n{e}")

    def on_extract_selected(self):
        sel = list(self.listbox.curselection())
        if not sel:
            messagebox.showinfo("Extract", "No files selected.")
            return
        out_dir = filedialog.askdirectory(title="Select folder to extract to")
        if not out_dir:
            return
        # If items came from package, pass indices relative to package read; but extract_from_fresh expects indices in package order.
        # If the current staging list has both files from disk and from package, easiest approach is:
        # - For items with src_path -> copy directly
        # - For items with pkg_src -> group by package and call extract_from_fresh
        written = []
        pkg_groups = {}  # pkg_path -> list of (package_index, staging_index)
        for idx in sel:
            it = self.items[idx]
            if it.get("src_path"):
                # copy file directly
                src = it["src_path"]
                name = it["name"]
                out_path = os.path.join(out_dir, name)
                base, ext = os.path.splitext(out_path)
                suffix = 1
                while os.path.exists(out_path):
                    out_path = f"{base} ({suffix}){ext}"
                    suffix += 1
                with open(src, "rb") as rf, open(out_path, "wb") as wf:
                    while True:
                        chunk = rf.read(65536)
                        if not chunk:
                            break
                        wf.write(chunk)
                written.append(out_path)
            else:
                # from package
                pkg = it.get("pkg_src")
                if pkg not in pkg_groups:
                    pkg_groups[pkg] = []
                # we need the package-local index for this item
                # compute package index by counting previous items in self.items that originate from same pkg
                package_index = self._compute_pkg_index_for_item(idx)
                pkg_groups[pkg].append(package_index)

        # now extract groups
        for pkg_path, indices in pkg_groups.items():
            try:
                out_paths = extract_from_fresh(pkg_path, out_dir, indices)
                written.extend(out_paths)
            except Exception as e:
                messagebox.showerror("Extract error", f"Error extracting from package {pkg_path}:\n{e}")

        self.status_var.set(f"Extracted {len(written)} file(s) to {out_dir}")
        messagebox.showinfo("Extract", f"Extracted {len(written)} file(s) to:\n{out_dir}")

    def _compute_pkg_index_for_item(self, staging_index: int) -> int:
        """
        Given a staging index in self.items, compute the 0-based index of that file within its source package.
        This assumes items from the same package are in the same relative order they were read (true for on_open).
        """
        target_item = self.items[staging_index]
        pkg_path = target_item.get("pkg_src")
        if not pkg_path:
            raise RuntimeError("Item not from package")

        idx = 0
        for i, it in enumerate(self.items):
            if it.get("pkg_src") == pkg_path:
                if i == staging_index:
                    return idx
                idx += 1
        raise RuntimeError("Could not compute package index")

    def on_extract_all(self):
        if not self.items:
            messagebox.showinfo("Extract All", "No files to extract.")
            return
        out_dir = filedialog.askdirectory(title="Select folder to extract to")
        if not out_dir:
            return
        written = []
        # copy disk files and group package files
        pkg_groups = {}
        for i, it in enumerate(self.items):
            if it.get("src_path"):
                src = it["src_path"]
                name = it["name"]
                out_path = os.path.join(out_dir, name)
                base, ext = os.path.splitext(out_path)
                suffix = 1
                while os.path.exists(out_path):
                    out_path = f"{base} ({suffix}){ext}"
                    suffix += 1
                with open(src, "rb") as rf, open(out_path, "wb") as wf:
                    while True:
                        chunk = rf.read(65536)
                        if not chunk:
                            break
                        wf.write(chunk)
                written.append(out_path)
            else:
                pkg = it.get("pkg_src")
                if pkg not in pkg_groups:
                    pkg_groups[pkg] = []
                # compute package index for i
                pkg_index = self._compute_pkg_index_for_item(i)
                pkg_groups[pkg].append(pkg_index)

        for pkg_path, indices in pkg_groups.items():
            try:
                out_paths = extract_from_fresh(pkg_path, out_dir, indices)
                written.extend(out_paths)
            except Exception as e:
                messagebox.showerror("Extract error", f"Error extracting from package {pkg_path}:\n{e}")

        self.status_var.set(f"Extracted {len(written)} file(s) to {out_dir}")
        messagebox.showinfo("Extract All", f"Extracted {len(written)} file(s) to:\n{out_dir}")

    def update_info(self):
        # Update info area about selected item
        sel = self.listbox.curselection()
        if not sel:
            self.info_text.config(state="normal")
            self.info_text.delete("1.0", tk.END)
            self.info_text.insert(tk.END, "No file selected.")
            self.info_text.config(state="disabled")
            return
        i = sel[0]
        it = self.items[i]
        lines = []
        lines.append(f"Name: {it['name']}")
        lines.append(f"Size: {human_size(int(it['size']))} ({it['size']} bytes)")
        if it.get("src_path"):
            lines.append(f"Source: {it['src_path']}")
        elif it.get("pkg_src"):
            lines.append(f"Source package: {it['pkg_src']}")
            lines.append(f"Package offset: {it.get('pkg_offset')}")
        self.info_text.config(state="normal")
        self.info_text.delete("1.0", tk.END)
        self.info_text.insert(tk.END, "\n".join(lines))
        self.info_text.config(state="disabled")

# -----------------------
# Run the app
# -----------------------
def main():
    root = tk.Tk()
    app = OranApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
