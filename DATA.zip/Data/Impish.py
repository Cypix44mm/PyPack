import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageDraw, ImageTk, ImageFont
import hashlib
import os

# ------------------ Mock malicious hash database ------------------
MALICIOUS_HASHES = {
    "d41d8cd98f00b204e9800998ecf8427e",
    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
}

# ------------------ Helper functions ------------------
def compute_hashes(file_path):
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                md5.update(chunk)
                sha256.update(chunk)
        return md5.hexdigest(), sha256.hexdigest()
    except:
        return None, None

def is_suspicious(file_path, md5_hash, sha256_hash):
    if md5_hash in MALICIOUS_HASHES or sha256_hash in MALICIOUS_HASHES:
        return True
    ext = os.path.splitext(file_path)[1].lower()
    return ext in (".exe", ".bat", ".cmd", ".scr", ".js")

def create_vertical_gradient(width, height, color1, color2):
    img = Image.new("RGB", (width, height), color1)
    draw = ImageDraw.Draw(img)
    r1, g1, b1 = int(color1[1:3],16), int(color1[3:5],16), int(color1[5:7],16)
    r2, g2, b2 = int(color2[1:3],16), int(color2[3:5],16), int(color2[5:7],16)
    for y in range(height):
        ratio = y / height
        r = int(r1*(1-ratio) + r2*ratio)
        g = int(g1*(1-ratio) + g2*ratio)
        b = int(b1*(1-ratio) + b2*ratio)
        draw.line([(0,y),(width,y)], fill=(r,g,b))
    return img

# ------------------ Main App ------------------
class VirusScannerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Impish Scanner")
        self.root.geometry("820x600")
        self.root.configure(bg="#e6f7d9")
        self.selected_files = []
        self.images = []
        self.setup_ui()

    def setup_ui(self):
        # Header gradient with text drawn directly
        grad_img = create_vertical_gradient(820, 60, "#a3e27f", "#d7f7d4")
        draw = ImageDraw.Draw(grad_img)
        try:
            font = ImageFont.load_default()
            draw.text((10, 20), "Impish Scanner", fill="#2f6b2f", font=font)
        except:
            pass
        self.header_photo = ImageTk.PhotoImage(grad_img)
        self.images.append(self.header_photo)
        header_label = tk.Label(self.root, image=self.header_photo, bd=0)
        header_label.place(x=0, y=0)

        # Listbox background
        list_bg_img = create_vertical_gradient(780, 400, "#d7f7d4", "#b6e7a9")
        self.list_bg_photo = ImageTk.PhotoImage(list_bg_img)
        self.images.append(self.list_bg_photo)
        list_frame = tk.Label(self.root, image=self.list_bg_photo, bd=2, relief="ridge")
        list_frame.place(x=20, y=80)
        self.listbox = tk.Listbox(list_frame, width=90, height=20, bg="#e6f7d9",
                                  fg="#2f6b2f", font=("Segoe UI",10))
        self.listbox.pack(padx=10, pady=10)

        # Buttons
        self.create_button("Select Files", self.select_files, 20, 500)
        self.create_button("Scan Files", self.scan_files, 150, 500)
        self.create_button("Clear List", self.clear_list, 280, 500)

    # ------------------ Button creation ------------------
    def create_button(self, text, command, x, y):
        btn_img = create_vertical_gradient(100, 30, "#a3e27f", "#7fd45c")
        draw = ImageDraw.Draw(btn_img)
        try:
            font = ImageFont.load_default()
            draw.text((10, 8), text, fill="#1b3d1b", font=font)
        except:
            pass
        photo = ImageTk.PhotoImage(btn_img)
        self.images.append(photo)
        btn = tk.Label(self.root, image=photo, bd=0)
        btn.image = photo
        btn.place(x=x, y=y)
        btn.bind("<Button-1>", lambda e: command())

    # ------------------ File operations ------------------
    def select_files(self):
        files = filedialog.askopenfilenames(title="Select files")
        for f in files:
            if f not in self.selected_files:
                self.selected_files.append(f)
                self.listbox.insert(tk.END,f)

    def scan_files(self):
        if not self.selected_files:
            messagebox.showwarning("No Files","Please select files to scan.")
            return
        self.listbox.delete(0,tk.END)
        for f in self.selected_files:
            md5_hash, sha256_hash = compute_hashes(f)
            if md5_hash is None:
                self.listbox.insert(tk.END,f"{f} – Error reading file")
                continue
            suspicious = is_suspicious(f, md5_hash, sha256_hash)
            status = "⚠️ Suspicious" if suspicious else "✅ Safe"
            self.listbox.insert(tk.END,f"{f} – {status} – MD5:{md5_hash[:8]}... SHA256:{sha256_hash[:8]}...")

    def clear_list(self):
        self.listbox.delete(0,tk.END)
        self.selected_files.clear()


if __name__ == "__main__":
    root = tk.Tk()
    app = VirusScannerApp(root)
    root.mainloop()
