import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageDraw, ImageTk, ImageFont
import subprocess
import threading
import hashlib
import tempfile
import shutil
import os
import sys
import time

# ----------------------
# Utilities / UI helpers
# ----------------------
def create_vertical_gradient(width, height, color1, color2):
    img = Image.new("RGB", (width, height), color1)
    draw = ImageDraw.Draw(img)
    r1, g1, b1 = int(color1[1:3], 16), int(color1[3:5], 16), int(color1[5:7], 16)
    r2, g2, b2 = int(color2[1:3], 16), int(color2[3:5], 16), int(color2[5:7], 16)
    for y in range(height):
        ratio = y / max(1, height - 1)
        r = int(r1 * (1 - ratio) + r2 * ratio)
        g = int(g1 * (1 - ratio) + g2 * ratio)
        b = int(b1 * (1 - ratio) + b2 * ratio)
        draw.line([(0, y), (width, y)], fill=(r, g, b))
    return img

def draw_text_centered(img, text, fill="#000000", y_offset=0):
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.load_default()
        w, h = draw.textsize(text, font=font)
        x = (img.width - w) // 2
        y = (img.height - h) // 2 + y_offset
        draw.text((x, y), text, fill=fill, font=font)
    except Exception:
        # best-effort fallback
        draw.text((8, img.height // 2 - 6 + y_offset), text, fill=fill)

def run_subprocess_and_stream(cmd, cwd, line_callback, finished_callback):
    """
    Run subprocess, stream stdout/stderr line-by-line to line_callback(line),
    and call finished_callback(returncode) when done.
    """
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            cwd=cwd,
            universal_newlines=True,
            bufsize=1
        )
    except FileNotFoundError as e:
        # command not found
        finished_callback(-1, f"Command not found: {cmd[0]}")
        return

    # Read lines
    try:
        for raw in proc.stdout:
            line = raw.rstrip("\n")
            line_callback(line)
        proc.wait()
        finished_callback(proc.returncode, None)
    except Exception as e:
        finished_callback(-1, str(e))

# ----------------------
# PyDVD Application
# ----------------------
class PyDVDApp:
    def __init__(self, root):
        self.root = root
        root.title("PyDVD - Python Deployment Vehicle & Distributor")
        root.geometry("920x640")
        root.configure(bg="#fff5eb")  # warm background

        # Keep references to PhotoImages so Tk doesn't GC them
        self._images = []

        # Paths and options
        self.script_path = tk.StringVar(value="")
        self.icon_path = tk.StringVar(value="")
        self.output_dir = tk.StringVar(value=os.path.expanduser("~"))
        self.exe_name = tk.StringVar(value="MyApp")

        # Build state
        self._build_thread = None

        self._build_ui()

    def _build_ui(self):
        # Header: sunrise gradient with text drawn onto image
        grad = create_vertical_gradient(920, 72, "#ffb347", "#ffd598")  # warm orange -> soft yellow
        draw_text_centered(grad, "PyDVD - Python Deployment Vehicle & Distributor", fill="#5b2e00", y_offset=-6)
        header_img = ImageTk.PhotoImage(grad)
        self._images.append(header_img)
        header_label = tk.Label(self.root, image=header_img, bd=0)
        header_label.place(x=0, y=0)

        # Subheader / instructions
        sub = tk.Label(self.root, text="Create a single-file Windows .exe (onefile + windowed).",
                       bg="#fff5eb", fg="#5b2e00", font=("Segoe UI", 10))
        sub.place(x=20, y=80)

        # Script selection
        tk.Label(self.root, text="Python script (.py):", bg="#fff5eb", fg="#5b2e00").place(x=20, y=110)
        tk.Entry(self.root, textvariable=self.script_path, width=76).place(x=20, y=135)
        self._button("Browse", self._browse_script, 740, 130)

        # Exe name
        tk.Label(self.root, text="Executable name (without .exe):", bg="#fff5eb", fg="#5b2e00").place(x=20, y=170)
        tk.Entry(self.root, textvariable=self.exe_name, width=40).place(x=250, y=168)

        # Icon selection (optional)
        tk.Label(self.root, text="Icon (optional .ico):", bg="#fff5eb", fg="#5b2e00").place(x=20, y=210)
        tk.Entry(self.root, textvariable=self.icon_path, width=58).place(x=20, y=235)
        self._button("Browse", self._browse_icon, 740, 232)

        # Output folder
        tk.Label(self.root, text="Output folder:", bg="#fff5eb", fg="#5b2e00").place(x=20, y=270)
        tk.Entry(self.root, textvariable=self.output_dir, width=76).place(x=20, y=295)
        self._button("Choose...", self._browse_output, 740, 292)

        # Build button
        build_btn = self._button("Build EXE", self._start_build, 20, 340, w=220, h=38, big=True)
        self.build_btn = build_btn

        # Clear log button + open output folder
        self._button("Open Output Folder", self._open_output_folder, 260, 340, w=180, h=38)
        self._button("Clear Log", self._clear_log, 460, 340, w=110, h=38)

        # Log box
        tb_frame = tk.Frame(self.root, bg="#fff5eb")
        tb_frame.place(x=20, y=400, width=880, height=220)
        self.log_box = tk.Text(tb_frame, wrap="none", state="disabled", bg="#fffaf0", fg="#2e2e2e")
        self.log_box.pack(side="left", fill="both", expand=True)
        # Scrollbars
        sb_v = tk.Scrollbar(tb_frame, orient="vertical", command=self.log_box.yview)
        sb_v.pack(side="right", fill="y")
        self.log_box.config(yscrollcommand=sb_v.set)
        sb_h = tk.Scrollbar(self.root, orient="horizontal", command=self.log_box.xview)
        sb_h.place(x=20, y=620, width=880, height=16)
        self.log_box.config(xscrollcommand=sb_h.set)

        # Footer note
        note = tk.Label(self.root, text="PyDVD uses PyInstaller under the hood. Make sure pyinstaller is installed.",
                        bg="#fff5eb", fg="#5b2e00", font=("Segoe UI", 9, "italic"))
        note.place(x=20, y=636 - 20)

    def _button(self, text, command, x, y, w=100, h=30, big=False):
        # create button image with gradient + text drawn
        if big:
            img = create_vertical_gradient(w, h, "#ff9a3c", "#ffcc66")
            text_color = "#3b1700"
        else:
            img = create_vertical_gradient(w, h, "#ffb347", "#ffc36b")
            text_color = "#3b1700"

        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.load_default()
            # center text
            tw, th = draw.textsize(text, font=font)
            draw.text(((w - tw) // 2, (h - th) // 2), text, fill=text_color, font=font)
        except Exception:
            try:
                draw.text((8, (h // 2) - 6), text, fill=text_color)
            except Exception:
                pass

        photo = ImageTk.PhotoImage(img)
        self._images.append(photo)
        lbl = tk.Label(self.root, image=photo, bd=0, cursor="hand2")
        lbl.image = photo
        lbl.place(x=x, y=y, width=w, height=h)
        lbl.bind("<Button-1>", lambda e: command())
        return lbl

    # ---------------- UI actions ----------------
    def _browse_script(self):
        p = filedialog.askopenfilename(title="Select Python script", filetypes=[("Python files","*.py")])
        if p:
            self.script_path.set(p)

    def _browse_icon(self):
        p = filedialog.askopenfilename(title="Select .ico (optional)", filetypes=[("Icon files","*.ico"),("All files","*.*")])
        if p:
            self.icon_path.set(p)

    def _browse_output(self):
        p = filedialog.askdirectory(title="Select output folder")
        if p:
            self.output_dir.set(p)

    def _open_output_folder(self):
        out = self.output_dir.get()
        if not os.path.isdir(out):
            messagebox.showwarning("No folder", "Output folder not found.")
            return
        if sys.platform.startswith("win"):
            os.startfile(out)
        elif sys.platform == "darwin":
            subprocess.call(["open", out])
        else:
            subprocess.call(["xdg-open", out])

    def _clear_log(self):
        self._append_log("\n" * 1, clear=True)

    def _append_log(self, text, clear=False):
        # thread-safe append
        def _do():
            if clear:
                self.log_box.config(state="normal")
                self.log_box.delete("1.0", tk.END)
                self.log_box.config(state="disabled")
            else:
                self.log_box.config(state="normal")
                self.log_box.insert(tk.END, text + "\n")
                self.log_box.see(tk.END)
                self.log_box.config(state="disabled")
        self.root.after(0, _do)

    # ---------------- Build logic ----------------
    def _start_build(self):
        script = self.script_path.get().strip()
        if not script or not os.path.isfile(script):
            messagebox.showerror("Missing script", "Choose a valid Python script (.py) first.")
            return

        # check pyinstaller availability
        if not self._pyinstaller_available():
            msg = ("PyInstaller is not available on PATH.\n\n"
                   "Install with:\n    python -m pip install pyinstaller\n\n"
                   "After installing, restart this app.")
            messagebox.showerror("PyInstaller not found", msg)
            return

        out_dir = self.output_dir.get().strip() or os.path.dirname(script)
        if not os.path.isdir(out_dir):
            try:
                os.makedirs(out_dir, exist_ok=True)
            except Exception as e:
                messagebox.showerror("Output folder error", f"Could not create output folder:\n{e}")
                return

        exe_name = self.exe_name.get().strip() or "MyApp"
        # Build command
        cmd = ["pyinstaller", "--noconfirm", "--onefile", "--windowed", "-n", exe_name, script]
        # optional icon
        icon = self.icon_path.get().strip()
        if icon and os.path.isfile(icon):
            cmd.extend(["--icon", icon])

        # use temp directories for work/spec to avoid clutter
        workdir = tempfile.mkdtemp(prefix="pydvd_build_")
        specdir = workdir  # specpath
        # instruct pyinstaller to put the final exe in output_dir
        cmd.extend(["--distpath", out_dir, "--workpath", workdir, "--specpath", specdir])

        # disable build button while building
        self.build_btn.unbind("<Button-1>")
        self._append_log(f"Starting build: {' '.join(cmd)}", clear=True)
        self._append_log(f"Output folder: {out_dir}")

        # run in background thread
        def line_cb(line):
            self._append_log(line)

        def finished_cb(returncode, error_text):
            # re-enable build button
            self.build_btn.bind("<Button-1>", lambda e: self._start_build())
            if error_text:
                self._append_log(f"ERROR: {error_text}")
                messagebox.showerror("Build failed", error_text)
            else:
                if returncode == 0:
                    self._append_log("Build finished successfully.")
                    messagebox.showinfo("Build finished", f"Executable created in:\n{out_dir}")
                else:
                    self._append_log(f"Build finished with return code {returncode}.")
                    messagebox.showwarning("Build finished", f"Process returned code {returncode}. Check log.")

            # cleanup workdir after short delay (give PyInstaller time to flush)
            try:
                shutil.rmtree(workdir)
            except Exception:
                pass

        # Start subprocess thread
        t = threading.Thread(target=run_subprocess_and_stream, args=(cmd, None, line_cb, finished_cb), daemon=True)
        t.start()
        self._build_thread = t

    def _pyinstaller_available(self):
        # try to run pyinstaller --version
        try:
            proc = subprocess.Popen(["pyinstaller", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = proc.communicate(timeout=5)
            return proc.returncode == 0
        except Exception:
            return False


def main():
    root = tk.Tk()
    app = PyDVDApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
