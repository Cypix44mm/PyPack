"""
Calcux - A high-school-level calculator with algebra & calculus tools.

Recommended (optional) dependency:
    python -m pip install sympy

Works without SymPy for basic numeric evaluation.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math
import sys

# Try optional import of sympy (for symbolic algebra/calculus)
_HAS_SYMPY = False
_sympy = None
try:
    import sympy as _sympy
    _HAS_SYMPY = True
except Exception:
    _HAS_SYMPY = False
    _sympy = None

# -------------------------
# Utilities (safe eval)
# -------------------------
# Provide a safe numeric namespace for eval if sympy not present
_SAFE_MATH = {
    "abs": abs, "round": round, "pow": pow,
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "asin": math.asin, "acos": math.acos, "atan": math.atan,
    "sqrt": math.sqrt, "log": math.log, "log10": math.log10,
    "exp": math.exp, "pi": math.pi, "e": math.e,
    # add more math functions if desired
}

def safe_numeric_eval(expr: str):
    """
    Evaluate numeric expressions safely using limited namespace.
    """
    try:
        # prevent access to builtins by giving empty __builtins__
        val = eval(expr, {"__builtins__": None}, _SAFE_MATH.copy())
        return val, None
    except Exception as e:
        return None, str(e)

# -------------------------
# Core calculator logic
# -------------------------
class CalcuxApp:
    def __init__(self, root):
        self.root = root
        root.title("Calcux - Calculator")
        root.geometry("700x520")
        root.configure(bg="#f7fbff")

        self._create_style()
        self._build_ui()

    def _create_style(self):
        # minimal ttk theme tweak (optional)
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except Exception:
            pass

    def _build_ui(self):
        # Top header
        header = tk.Label(self.root, text="Calcux", font=("Segoe UI", 18, "bold"), bg="#f7fbff", fg="#073b4c")
        header.pack(pady=(10, 4))

        subtitle = tk.Label(self.root, text="Basic → Algebra → Calculus (SymPy recommended)", font=("Segoe UI", 10),
                            bg="#f7fbff", fg="#1167b1")
        subtitle.pack(pady=(0, 10))

        # Notebook for modes
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=12, pady=8)

        # Basic calculator tab
        self.tab_basic = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_basic, text="Basic")

        # Algebra tab
        self.tab_algebra = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_algebra, text="Algebra")

        # Calculus tab
        self.tab_calc = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_calc, text="Calculus")

        # Build contents
        self._build_basic_tab()
        self._build_algebra_tab()
        self._build_calculus_tab()

        # Footer / status
        status_frame = tk.Frame(self.root, bg="#f7fbff")
        status_frame.pack(fill="x", padx=12, pady=(0,10))
        if not _HAS_SYMPY:
            note = tk.Label(status_frame, text="SymPy not installed — advanced symbolic features disabled. Install with: python -m pip install sympy",
                            fg="#b02a2a", bg="#fff3f3", font=("Segoe UI", 9), anchor="w", padx=6)
            note.pack(fill="x")
        else:
            note = tk.Label(status_frame, text="SymPy available — full symbolic features enabled.", fg="#1a7f37",
                            bg="#e9f7ee", font=("Segoe UI", 9), anchor="w", padx=6)
            note.pack(fill="x")

    # ---------------------
    # Basic tab UI
    # ---------------------
    def _build_basic_tab(self):
        frame = self.tab_basic
        left = tk.Frame(frame)
        left.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        # Entry display
        self.basic_entry = tk.Entry(left, font=("Consolas", 18), justify="right")
        self.basic_entry.pack(fill="x", padx=6, pady=(6,12))
        self.basic_entry.bind("<Return>", lambda e: self._basic_evaluate())

        # Buttons grid
        btn_frame = tk.Frame(left)
        btn_frame.pack()

        buttons = [
            ("7", self._basic_insert), ("8", self._basic_insert), ("9", self._basic_insert), ("/", self._basic_insert),
            ("4", self._basic_insert), ("5", self._basic_insert), ("6", self._basic_insert), ("*", self._basic_insert),
            ("1", self._basic_insert), ("2", self._basic_insert), ("3", self._basic_insert), ("-", self._basic_insert),
            ("0", self._basic_insert), (".", self._basic_insert), ("(", self._basic_insert), (")", self._basic_insert),
            ("C", self._basic_clear), ("←", self._basic_backspace), ("=", self._basic_evaluate), ("+", self._basic_insert),
        ]
        r = 0
        c = 0
        for (txt, cmd) in buttons:
            b = tk.Button(btn_frame, text=txt, width=6, height=2, font=("Segoe UI", 11),
                          command=lambda t=txt, fn=cmd: fn(t))
            b.grid(row=r, column=c, padx=3, pady=3)
            c += 1
            if c >= 4:
                c = 0
                r += 1

        right = tk.Frame(frame, width=260)
        right.pack(side="right", fill="y", padx=8, pady=8)

        tk.Label(right, text="History", font=("Segoe UI", 11, "bold")).pack(anchor="nw")
        self.basic_history = tk.Text(right, width=30, height=18, state="disabled", bg="#fbfdff")
        self.basic_history.pack(padx=6, pady=6)

    def _basic_insert(self, token):
        cur = self.basic_entry.get()
        self.basic_entry.delete(0, tk.END)
        self.basic_entry.insert(0, cur + token)

    def _basic_clear(self, _=None):
        self.basic_entry.delete(0, tk.END)

    def _basic_backspace(self, _=None):
        s = self.basic_entry.get()
        self.basic_entry.delete(0, tk.END)
        self.basic_entry.insert(0, s[:-1])

    def _basic_evaluate(self, _=None):
        expr = self.basic_entry.get().strip()
        if not expr:
            return
        # Prefer sympy numeric eval if available
        if _HAS_SYMPY:
            try:
                val = _sympy.N(_sympy.sympify(expr))
                out = str(val)
                self._append_basic_history(f"{expr} = {out}")
                self.basic_entry.delete(0, tk.END)
                self.basic_entry.insert(0, out)
                return
            except Exception:
                pass
        # fallback numeric eval
        val, err = safe_numeric_eval(expr)
        if err:
            messagebox.showerror("Evaluation error", f"Could not evaluate expression:\n{err}")
            return
        self._append_basic_history(f"{expr} = {val}")
        self.basic_entry.delete(0, tk.END)
        self.basic_entry.insert(0, str(val))

    def _append_basic_history(self, line):
        self.basic_history.configure(state="normal")
        self.basic_history.insert(tk.END, line + "\n")
        self.basic_history.configure(state="disabled")

    # ---------------------
    # Algebra tab
    # ---------------------
    def _build_algebra_tab(self):
        frame = self.tab_algebra
        top = tk.Frame(frame)
        top.pack(fill="x", padx=8, pady=8)

        tk.Label(top, text="Equation or expression (e.g. 2*x+3=7 or x**2-5*x+6):", bg="#fff", font=("Segoe UI", 10)).pack(anchor="w")
        self.algebra_entry = tk.Entry(top, width=60, font=("Consolas", 12))
        self.algebra_entry.pack(fill="x", pady=(4,6))
        btn_row = tk.Frame(top)
        btn_row.pack(fill="x", pady=(0,6))
        tk.Button(btn_row, text="Solve (for x)", command=self._algebra_solve, bg="#e8f4ff").pack(side="left", padx=4)
        tk.Button(btn_row, text="Factor", command=self._algebra_factor, bg="#e8f4ff").pack(side="left", padx=4)
        tk.Button(btn_row, text="Expand", command=self._algebra_expand, bg="#e8f4ff").pack(side="left", padx=4)
        tk.Button(btn_row, text="Roots", command=self._algebra_roots, bg="#e8f4ff").pack(side="left", padx=4)

        # Result display
        self.algebra_output = tk.Text(frame, height=14, bg="#fbfeff")
        self.algebra_output.pack(fill="both", padx=8, pady=(0,8))

        if not _HAS_SYMPY:
            self.algebra_output.configure(state="normal")
            self.algebra_output.insert(tk.END, "SymPy is required for algebraic operations.\nInstall: python -m pip install sympy\n")
            self.algebra_output.configure(state="disabled")

    def _algebra_solve(self):
        expr = self.algebra_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to use symbolic solving:\npython -m pip install sympy")
            return
        try:
            if "=" in expr:
                left, right = expr.split("=", 1)
                eq = _sympy.Eq(_sympy.sympify(left), _sympy.sympify(right))
                sol = _sympy.solve(eq)
            else:
                # treat as expression == 0
                sol = _sympy.solve(_sympy.sympify(expr))
            self._set_algebra_output(f"Solve: {expr}\nResult: {sol}")
        except Exception as e:
            self._set_algebra_output(f"Error: {e}")

    def _algebra_factor(self):
        expr = self.algebra_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to use factoring.")
            return
        try:
            f = _sympy.factor(_sympy.sympify(expr))
            self._set_algebra_output(f"Factor({expr}) = {f}")
        except Exception as e:
            self._set_algebra_output(f"Error: {e}")

    def _algebra_expand(self):
        expr = self.algebra_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to use expand.")
            return
        try:
            x = _sympy.expand(_sympy.sympify(expr))
            self._set_algebra_output(f"Expand({expr}) = {x}")
        except Exception as e:
            self._set_algebra_output(f"Error: {e}")

    def _algebra_roots(self):
        expr = self.algebra_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to get polynomial roots.")
            return
        try:
            poly = _sympy.Poly(_sympy.sympify(expr))
            roots = poly.nroots()
            self._set_algebra_output(f"Polynomial roots of {expr}:\n{roots}")
        except Exception as e:
            self._set_algebra_output(f"Error: {e}")

    def _set_algebra_output(self, txt):
        self.algebra_output.configure(state="normal")
        self.algebra_output.delete("1.0", tk.END)
        self.algebra_output.insert(tk.END, txt)
        self.algebra_output.configure(state="disabled")

    # ---------------------
    # Calculus tab
    # ---------------------
    def _build_calculus_tab(self):
        frame = self.tab_calc
        top = tk.Frame(frame)
        top.pack(fill="x", padx=8, pady=8)

        tk.Label(top, text="Expression (in x), e.g. sin(x)*x**2 + 3:", bg="#fff").pack(anchor="w")
        self.calc_entry = tk.Entry(top, width=60, font=("Consolas", 12))
        self.calc_entry.pack(fill="x", pady=(4,6))

        ops = tk.Frame(top)
        ops.pack(fill="x", pady=(0,6))
        tk.Button(ops, text="Differentiate", command=self._calc_diff, bg="#f0f8ff").pack(side="left", padx=6)
        tk.Button(ops, text="Integrate (indef)", command=self._calc_int, bg="#f0f8ff").pack(side="left", padx=6)
        tk.Button(ops, text="Integrate (def)", command=self._calc_int_def, bg="#f0f8ff").pack(side="left", padx=6)

        self.calc_output = tk.Text(frame, height=14, bg="#fbfeff")
        self.calc_output.pack(fill="both", padx=8, pady=(0,8))

        if not _HAS_SYMPY:
            self.calc_output.configure(state="normal")
            self.calc_output.insert(tk.END, "SymPy required for calculus operations.\nInstall: python -m pip install sympy\n")
            self.calc_output.configure(state="disabled")

    def _calc_diff(self):
        expr = self.calc_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to use symbolic differentiation.")
            return
        try:
            x = _sympy.symbols('x')
            res = _sympy.diff(_sympy.sympify(expr), x)
            self._set_calc_output(f"d/dx {expr} = {res}")
        except Exception as e:
            self._set_calc_output(f"Error: {e}")

    def _calc_int(self):
        expr = self.calc_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to use symbolic integration.")
            return
        try:
            x = _sympy.symbols('x')
            res = _sympy.integrate(_sympy.sympify(expr), x)
            self._set_calc_output(f"∫ {expr} dx = {res} + C")
        except Exception as e:
            self._set_calc_output(f"Error: {e}")

    def _calc_int_def(self):
        # ask user for bounds via small popup
        expr = self.calc_entry.get().strip()
        if not expr:
            return
        if not _HAS_SYMPY:
            messagebox.showinfo("SymPy required", "Install SymPy to use definite integrals.")
            return
        bounds = self._ask_bounds()
        if not bounds:
            return
        a, b = bounds
        try:
            x = _sympy.symbols('x')
            val = _sympy.integrate(_sympy.sympify(expr), (x, _sympy.N(a), _sympy.N(b)))
            self._set_calc_output(f"∫_{a}^{b} {expr} dx = {val}")
        except Exception as e:
            self._set_calc_output(f"Error: {e}")

    def _ask_bounds(self):
        # small simple dialog for two numbers
        popup = tk.Toplevel(self.root)
        popup.title("Definite integral bounds")
        tk.Label(popup, text="Lower bound:").grid(row=0, column=0, padx=6, pady=6)
        e1 = tk.Entry(popup); e1.grid(row=0, column=1, padx=6, pady=6)
        tk.Label(popup, text="Upper bound:").grid(row=1, column=0, padx=6, pady=6)
        e2 = tk.Entry(popup); e2.grid(row=1, column=1, padx=6, pady=6)

        res = {"ok": False, "a": None, "b": None}
        def do_ok():
            try:
                a = float(e1.get().strip()); b = float(e2.get().strip())
                res["ok"] = True; res["a"] = a; res["b"] = b
                popup.destroy()
            except Exception:
                messagebox.showerror("Invalid", "Enter numeric bounds (e.g. 0, 2.5)")

        tk.Button(popup, text="OK", command=do_ok).grid(row=2, column=0, columnspan=2, pady=8)
        popup.grab_set()
        self.root.wait_window(popup)
        if not res["ok"]:
            return None
        return res["a"], res["b"]

    def _set_calc_output(self, txt):
        self.calc_output.configure(state="normal")
        self.calc_output.delete("1.0", tk.END)
        self.calc_output.insert(tk.END, txt)
        self.calc_output.configure(state="disabled")

# -------------------------
# Launch
# -------------------------
def main():
    root = tk.Tk()
    app = CalcuxApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
