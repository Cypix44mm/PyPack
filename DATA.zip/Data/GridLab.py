import tkinter as tk
from tkinter import messagebox
import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
import math

matplotlib.use("TkAgg")

def polygon_area(points):
    if len(points) < 3:
        return 0
    n = len(points)
    area = 0
    for i in range(n):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) / 2

def polygon_perimeter(points):
    if len(points) < 2:
        return 0
    perim = 0
    for i in range(len(points)):
        x1, y1 = points[i]
        x2, y2 = points[(i + 1) % len(points)]
        perim += math.dist((x1, y1), (x2, y2))
    return perim

def detect_shape(points):
    if len(points) == 3:
        return "Triangle"
    elif len(points) == 4:
        d = [math.dist(points[i], points[(i+1)%4]) for i in range(4)]
        diag1 = math.dist(points[0], points[2])
        diag2 = math.dist(points[1], points[3])
        if abs(diag1 - diag2) < 0.01 and abs(max(d) - min(d)) < 0.01:
            return "Square"
        elif abs(diag1 - diag2) < 0.01:
            return "Rectangle"
        else:
            return "Quadrilateral"
    elif len(points) > 4:
        return "Polygon"
    return "Line"

class GridLabApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GridLab - Cartesian Geometry Tool")
        self.root.geometry("900x800")
        self.root.configure(bg="#eef3ff")

        self.points = []
        self.analytical_mode = False

        # Matplotlib figure setup
        self.fig, self.ax = plt.subplots(figsize=(6.5, 6.5))
        self.ax.set_facecolor("#ffffff")
        self.ax.grid(True, color="#b0c4de", linestyle='-', linewidth=0.5)
        self.ax.axhline(0, color="blue", linewidth=1.2)
        self.ax.axvline(0, color="blue", linewidth=1.2)
        self.ax.set_xlim(-15, 15)
        self.ax.set_ylim(-15, 15)
        self.ax.set_xticks(range(-15, 16))
        self.ax.set_yticks(range(-15, 16))

        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        self.canvas.get_tk_widget().pack(pady=10)
        self.canvas.mpl_connect("button_press_event", self.on_click)

        # Buttons
        btn_frame = tk.Frame(self.root, bg="#eef3ff")
        btn_frame.pack()

        tk.Button(btn_frame, text="Connect Points", command=self.connect_points,
                  bg="#dde7ff", fg="red", font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=10, pady=5).grid(row=0, column=0, padx=10)

        tk.Button(btn_frame, text="Clear", command=self.clear_all,
                  bg="#dde7ff", fg="blue", font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=10, pady=5).grid(row=0, column=1, padx=10)

        tk.Button(btn_frame, text="Toggle Analytical Mode", command=self.toggle_analytical,
                  bg="#dde7ff", fg="darkgreen", font=("Segoe UI", 11, "bold"),
                  relief="flat", padx=10, pady=5).grid(row=0, column=2, padx=10)

        self.info_label = tk.Label(self.root, text="Click on the grid or use analytical mode to add points.",
                                   bg="#eef3ff", fg="#333", font=("Segoe UI", 11))
        self.info_label.pack(pady=5)

        # Analytical entry
        self.analytical_frame = tk.Frame(self.root, bg="#eef3ff")
        self.analytical_label = tk.Label(self.analytical_frame, text="Enter point (x, y):",
                                         bg="#eef3ff", fg="black", font=("Segoe UI", 11))
        self.analytical_label.grid(row=0, column=0, padx=5)
        self.analytical_entry = tk.Entry(self.analytical_frame, width=15)
        self.analytical_entry.grid(row=0, column=1, padx=5)
        self.add_point_btn = tk.Button(self.analytical_frame, text="Add Point",
                                       command=self.add_point_analytical,
                                       bg="#dde7ff", fg="darkred", font=("Segoe UI", 10, "bold"), relief="flat")
        self.add_point_btn.grid(row=0, column=2, padx=5)

    def on_click(self, event):
        """Click to add a point snapped to nearest intersection"""
        if event.xdata is None or event.ydata is None:
            return
        x, y = round(event.xdata), round(event.ydata)
        self.add_point((x, y))

    def add_point(self, point):
        """Add point and plot"""
        self.points.append(point)
        x, y = point
        self.ax.plot(x, y, "o", color="red")
        self.ax.text(x + 0.2, y + 0.2, f"({x}, {y})", color="red", fontsize=9)
        self.canvas.draw()

    def add_point_analytical(self):
        """Add a point by typing coordinates"""
        try:
            raw = self.analytical_entry.get().replace("(", "").replace(")", "")
            x, y = map(float, raw.split(","))
            self.add_point((round(x), round(y)))
            self.analytical_entry.delete(0, tk.END)
        except Exception:
            messagebox.showerror("Invalid Input", "Enter coordinates like: (3, 5)")

    def connect_points(self):
        """Connect points and calculate shape data"""
        if len(self.points) < 2:
            messagebox.showwarning("Not enough points", "Add at least 2 points first!")
            return

        polygon = Polygon(self.points, closed=True, fill=False, edgecolor="red", linewidth=2)
        self.ax.add_patch(polygon)
        self.canvas.draw()

        perim = polygon_perimeter(self.points)
        area = polygon_area(self.points)
        shape_type = detect_shape(self.points)

        info = f"{shape_type} | Perimeter: {perim:.2f}"
        if len(self.points) >= 3:
            info += f" | Area: {area:.2f}"
        self.info_label.config(text=info, fg="red")

    def clear_all(self):
        """Reset canvas and points"""
        self.points.clear()
        self.ax.clear()
        self.ax.set_facecolor("#ffffff")
        self.ax.grid(True, color="#b0c4de", linestyle='-', linewidth=0.5)
        self.ax.axhline(0, color="blue", linewidth=1.2)
        self.ax.axvline(0, color="blue", linewidth=1.2)
        self.ax.set_xlim(-15, 15)
        self.ax.set_ylim(-15, 15)
        self.ax.set_xticks(range(-15, 16))
        self.ax.set_yticks(range(-15, 16))
        self.info_label.config(text="Click on the grid or use analytical mode to add points.", fg="#333")
        self.canvas.draw()

    def toggle_analytical(self):
        """Show or hide analytical input"""
        self.analytical_mode = not self.analytical_mode
        if self.analytical_mode:
            self.analytical_frame.pack(pady=5)
        else:
            self.analytical_frame.pack_forget()

if __name__ == "__main__":
    root = tk.Tk()
    app = GridLabApp(root)
    root.mainloop()
